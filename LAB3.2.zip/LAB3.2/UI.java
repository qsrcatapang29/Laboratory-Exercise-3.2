import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

public class UI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtTitle;
    private JTextField txtAuthor;
    private JTextField txtISBN;
    private JTextField txtGenre;
    private JTextField txtSearch;
    private JTable table;
    private DefaultTableModel tableModel;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                UI frame = new UI();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public UI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1133, 585);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        contentPane.setBackground(Color.decode("#669999"));

        // Title Label
        JLabel lblNewLabel = new JLabel("Library Management");
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 40));
        lblNewLabel.setBounds(25, 56, 377, 62);
        contentPane.add(lblNewLabel);
        
        

        // Labels and Text Fields for Book Details
        JLabel lblNewLabel_1 = new JLabel("Title:");
        lblNewLabel_1.setFont(new Font("Times New Roman", Font.ITALIC, 25));
        lblNewLabel_1.setBounds(25, 150, 78, 45);
        contentPane.add(lblNewLabel_1);

        txtTitle = new JTextField();
        txtTitle.setBounds(142, 163, 260, 26);
        contentPane.add(txtTitle);
        txtTitle.setColumns(10);

        JLabel lblNewLabel_1_1 = new JLabel("Author:");
        lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.ITALIC, 25));
        lblNewLabel_1_1.setBounds(25, 206, 107, 45);
        contentPane.add(lblNewLabel_1_1);

        txtAuthor = new JTextField();
        txtAuthor.setColumns(10);
        txtAuthor.setBounds(142, 222, 260, 26);
        contentPane.add(txtAuthor);

        JLabel lblNewLabel_1_2 = new JLabel("ISBN:");
        lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.ITALIC, 25));
        lblNewLabel_1_2.setBounds(25, 262, 78, 45);
        contentPane.add(lblNewLabel_1_2);

        txtISBN = new JTextField();
        txtISBN.setColumns(10);
        txtISBN.setBounds(142, 278, 260, 26);
        contentPane.add(txtISBN);

        JLabel lblNewLabel_1_3 = new JLabel("Genre:");
        lblNewLabel_1_3.setFont(new Font("Times New Roman", Font.ITALIC, 25));
        lblNewLabel_1_3.setBounds(25, 318, 78, 45);
        contentPane.add(lblNewLabel_1_3);

        txtGenre = new JTextField();
        txtGenre.setColumns(10);
        txtGenre.setBounds(142, 334, 260, 26);
        contentPane.add(txtGenre);
        


        // Buttons to Add Book
        JButton btnAddBook = new JButton("Add Book");
        btnAddBook.setFont(new Font("Times New Roman", Font.BOLD, 20));
        btnAddBook.setBounds(35, 374, 167, 38);
        contentPane.add(btnAddBook);

        // Search Bar
        JLabel lblSearch = new JLabel("Search:");
        lblSearch.setFont(new Font("Times New Roman", Font.ITALIC, 25));
        lblSearch.setBounds(488, 70, 107, 45);
        contentPane.add(lblSearch);

        txtSearch = new JTextField();
        txtSearch.setBounds(583, 83, 360, 26);
        contentPane.add(txtSearch);

        // Table to Display List of Books
        String[] columnNames = {"Title", "Author", "ISBN", "Genre"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(488, 126, 600, 381);
        contentPane.add(scrollPane);
        
        JButton btnAddBook_1 = new JButton("Remove Books");
        btnAddBook_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        btnAddBook_1.setBounds(212, 374, 172, 38);
        contentPane.add(btnAddBook_1);
        
        JButton btnSortByIsbn = new JButton("Sort by ISBN (Descending)");
        btnSortByIsbn.setFont(new Font("Times New Roman", Font.BOLD, 19));
        btnSortByIsbn.setBounds(35, 420, 349, 38);
        contentPane.add(btnSortByIsbn);
        
        JButton btnSortByTitle = new JButton("Sort by Title (Alphabetical)");
        btnSortByTitle.setFont(new Font("Times New Roman", Font.BOLD, 19));
        btnSortByTitle.setBounds(35, 469, 349, 38);
        contentPane.add(btnSortByTitle);
        
        JButton btnNewButton = new JButton("Search");
        btnNewButton.setBounds(953, 85, 89, 23);
        contentPane.add(btnNewButton);
        
        // Search button action listener
btnNewButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        String query = txtSearch.getText();
        filter(query);
    }
});

        // Add Book to Table when Button is Pressed
        btnAddBook.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String title = txtTitle.getText();
                String author = txtAuthor.getText();
                String isbn = txtISBN.getText();
                String genre = txtGenre.getText();

                // Add book details to the table
                tableModel.addRow(new Object[]{title, author, isbn, genre});

                // Clear text fields after adding
                txtTitle.setText("");
                txtAuthor.setText("");
                txtISBN.setText("");
                txtGenre.setText("");
            }
        });
        
        // Remove Books button action listener
        btnAddBook_1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        int[] selectedRows = table.getSelectedRows();
        for (int i = selectedRows.length - 1; i >= 0; i--) {
            tableModel.removeRow(selectedRows[i]);
        }
            }
        }); 
        
        // Sort by ISBN (Descending) button action listener
     btnSortByIsbn.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        int rowCount = tableModel.getRowCount();
        String[][] data = new String[rowCount][4];

        for (int i = 0; i < rowCount; i++) {
            data[i][0] = tableModel.getValueAt(i, 0).toString();
            data[i][1] = tableModel.getValueAt(i, 1).toString();
            data[i][2] = tableModel.getValueAt(i, 2).toString();
            data[i][3] = tableModel.getValueAt(i, 3).toString();
        }

        // Sort data by ISBN in descending order
        for (int i = 0; i < rowCount - 1; i++) {
            for (int j = i + 1; j < rowCount; j++) {
                if (data[i][2].compareTo(data[j][2]) < 0) {
                    String[] temp = data[i];
                    data[i] = data[j];
                    data[j] = temp;
                }
            }
        }

        // Update table model with sorted data
        tableModel.setRowCount(0);
        for (int i = 0; i < rowCount; i++) {
            tableModel.addRow(data[i]);
        }
    }
});

// Sort by Title (Alphabetical) button action listener
btnSortByTitle.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        int rowCount = tableModel.getRowCount();
        String[][] data = new String[rowCount][4];

        for (int i = 0; i < rowCount; i++) {
            data[i][0] = tableModel.getValueAt(i, 0).toString();
            data[i][1] = tableModel.getValueAt(i, 1).toString();
            data[i][2] = tableModel.getValueAt(i, 2).toString();
            data[i][3] = tableModel.getValueAt(i, 3).toString();
        }

        // Sort data by title in alphabetical order
        for (int i = 0; i < rowCount - 1; i++) {
            for (int j = i + 1; j < rowCount; j++) {
                if (data[i][0].compareTo(data[j][0]) > 0) {
                    String[] temp = data[i];
                    data[i] = data[j];
                    data[j] = temp;
                }
            }
        }

        // Update table model with sorted data
        tableModel.setRowCount(0);
        for (int i = 0; i < rowCount; i++) {
            tableModel.addRow(data[i]);
        }
    }
});
        
        // Filter books in the table when search text is typed
        txtSearch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String query = txtSearch.getText();
                filter(query);
            }
        });
    }


    // Filter method to search books in the table
    private void filter(String query) {
        DefaultTableModel filteredModel = new DefaultTableModel(new String[]{"Title", "Author", "ISBN", "Genre"}, 0);

        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String title = tableModel.getValueAt(i, 0).toString().toLowerCase();
            String author = tableModel.getValueAt(i, 1).toString().toLowerCase();
            String isbn = tableModel.getValueAt(i, 2).toString().toLowerCase();
            String genre = tableModel.getValueAt(i, 3).toString().toLowerCase();

            if (title.contains(query.toLowerCase()) || author.contains(query.toLowerCase())
                    || isbn.contains(query.toLowerCase()) || genre.contains(query.toLowerCase())) {
                filteredModel.addRow(new Object[]{title, author, isbn, genre});
            }
        }

        table.setModel(filteredModel);
    }
}